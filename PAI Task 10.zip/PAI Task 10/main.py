from utils.sentiment import analyze_sentiment
from utils.preprocessing import clean_text

print("\n====== NLP Sentiment Analysis Project ======\n")

while True:
    text = input("Enter a sentence (or type exit): ")

    if text.lower() == "exit":
        print("Program Closed.")
        break

    cleaned = clean_text(text)

    sentiment, polarity = analyze_sentiment(cleaned)

    print("\nCleaned Text:", cleaned)
    print("Polarity Score:", polarity)
    print("Sentiment:", sentiment)

    # Save result in file
    with open("outputs/results.txt", "a") as file:
        file.write(f"\nText: {text}")
        file.write(f"\nCleaned: {cleaned}")
        file.write(f"\nPolarity: {polarity}")
        file.write(f"\nSentiment: {sentiment}")
        file.write("\n--------------------------")

    print("\nResult saved successfully.\n")
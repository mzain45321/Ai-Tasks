# NLP Sentiment Analysis Project

## Description
This project performs Sentiment Analysis using NLP techniques.

The program:
- Takes user input
- Cleans the text
- Detects sentiment
- Shows polarity score
- Saves results in a text file

## Technologies Used
- Python
- TextBlob
- NLP

## Installation

Install dependencies:

pip install -r requirements.txt

## Run Project

python main.py

## Author
Muhammad Zain
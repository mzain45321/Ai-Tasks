from flask import Flask, render_template, request
from sentence_transformers import SentenceTransformer
import faiss
import numpy as np
import pickle

app = Flask(__name__)

# Load MiniLM model
model = SentenceTransformer('all-MiniLM-L6-v2')

# Load FAISS index
index = faiss.read_index("medical_index.faiss")

# Load dataset
with open("qa_data.pkl", "rb") as f:

    questions, answers = pickle.load(f)

@app.route("/", methods=["GET", "POST"])
def home():

    answer = ""

    if request.method == "POST":

        user_question = request.form["question"]

        # Generate embedding
        vector = model.encode([user_question])

        vector = np.array(vector).astype("float32")

        # Search similar vector
        D, I = index.search(vector, 1)

        similarity_score = D[0][0]

        # Optional threshold check
        if similarity_score > 5:

            answer = "Sorry, I could not understand your question."

        else:

            answer = answers[I[0][0]]

    return render_template("index.html", answer=answer)

if __name__ == "__main__":
    app.run(debug=True)
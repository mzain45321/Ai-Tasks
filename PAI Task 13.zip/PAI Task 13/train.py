from sentence_transformers import SentenceTransformer
import faiss
import numpy as np
import pickle

# Load embedding model
model = SentenceTransformer('all-MiniLM-L6-v2')

questions = []
answers = []

# Read dataset
with open("data.txt", "r", encoding="utf-8") as file:

    lines = file.readlines()

for line in lines:

    if "|" in line:

        q, a = line.strip().split("|")

        questions.append(q)
        answers.append(a)

# Generate embeddings
embeddings = model.encode(questions)

# Convert to numpy float32
embeddings = np.array(embeddings).astype("float32")

# Create FAISS index
dimension = embeddings.shape[1]

index = faiss.IndexFlatL2(dimension)

# Add vectors
index.add(embeddings)

# Save FAISS index
faiss.write_index(index, "medical_index.faiss")

# Save QnA data
with open("qa_data.pkl", "wb") as f:

    pickle.dump((questions, answers), f)

print("Medical Bot Training Completed!")
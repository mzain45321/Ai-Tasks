import requests
import re
import csv
import time
import urllib3

urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

headers = {
    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64)"
}

email_pattern = r"[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}"

# read websites
with open("urls.txt","r") as f:
    websites = f.read().splitlines()

contact_pages = ["", "/contact", "/contact-us", "/about"]

all_emails = set()

for site in websites:
    for page in contact_pages:

        url = site.rstrip("/") + page   # URL yahan define ho raha hai

        try:
            r = requests.get(url, headers=headers, timeout=15, verify=False)

            emails = re.findall(email_pattern, r.text)

            for email in emails:

                if "sentry" in email.lower() or "wix" in email.lower():
                    continue

                if email not in all_emails:
                    print(url, "->", email)

                all_emails.add(email)

        except:
            print("Error accessing:", url)

# save emails
with open("emails.csv","w",newline="") as f:
    writer = csv.writer(f)
    writer.writerow(["Email"])

    for email in all_emails:
        writer.writerow([email])

print("\nTotal Emails:",len(all_emails))
print("Saved to emails.csv")
function sendMessage() {

    let inputField = document.getElementById("userInput");

    let userText = inputField.value.trim();

    if(userText === ""){
        return;
    }

    let chatbox = document.getElementById("chatbox");

    // User Message
    let userDiv = document.createElement("div");
    userDiv.className = "user-message";
    userDiv.innerHTML = userText;

    chatbox.appendChild(userDiv);

    // Auto Scroll
    chatbox.scrollTop = chatbox.scrollHeight;

    fetch("/get",{
        method:"POST",
        headers:{
            "Content-Type":"application/x-www-form-urlencoded"
        },
        body:"msg=" + encodeURIComponent(userText)
    })

    .then(response => response.json())

    .then(data => {

        // Bot Message
        let botDiv = document.createElement("div");
        botDiv.className = "bot-message";

        setTimeout(() => {

            botDiv.innerHTML = data.reply;

            chatbox.appendChild(botDiv);

            chatbox.scrollTop = chatbox.scrollHeight;

        }, 500);

    });

    inputField.value = "";
}

function handleEnter(event){

    if(event.key === "Enter"){
        sendMessage();
    }
}

function quickMessage(text){

    document.getElementById("userInput").value = text;

    sendMessage();
}
def get_bot_response(user_input):

    message = user_input.lower().strip()

    # Greetings
    if any(word in message for word in ["hello", "hi", "hey", "salam"]):
        return "Hello 👋 Welcome to the University Admission Chatbot!"

    # Admission
    elif "admission" in message:
        return "Admissions are open for Fall 2026."

    # Deadline
    elif "deadline" in message or "last date" in message:
        return "The last date to apply is 30 September 2026."

    # Programs
    elif any(word in message for word in ["program", "programs", "courses", "degree"]):
        return "We offer BSCS, BSIT, Software Engineering, BBA, and Artificial Intelligence."

    # Fee Structure
    elif "fee" in message or "fees" in message:
        return "The average semester fee is approximately 75,000 PKR."

    # Scholarship
    elif "scholarship" in message:
        return "Yes, merit-based and need-based scholarships are available."

    # Hostel
    elif "hostel" in message:
        return "Yes, separate hostel facilities are available for boys and girls."

    # Location
    elif "location" in message or "address" in message:
        return "Our university is located in Rahim Yar Khan, Punjab."

    # Contact
    elif "contact" in message or "phone" in message:
        return "You can contact us at 0300-1234567."

    # Timing
    elif "timing" in message or "hours" in message:
        return "University timing is from 8 AM to 4 PM."

    # Merit
    elif "merit" in message:
        return "Last year BSCS merit was around 78%."

    # Thanks
    elif "thank" in message:
        return "You're welcome 😊"

    # Bye
    elif "bye" in message or "goodbye" in message:
        return "Goodbye 👋 Have a great day!"

    # Default
    else:
        return "Sorry 😔 I did not understand your question. Please ask about admissions, fees, programs, scholarships, or deadlines."